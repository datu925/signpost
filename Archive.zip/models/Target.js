function Target(target_details) {
  // this.id = target_details["id"];
  this.anchor = target_details["anchor"];
  this.text = target_details["text"];
  this.x = target_details["x"];
  this.y = target_details["y"];
  this.shortcut = null;
}
